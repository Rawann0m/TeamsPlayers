//
//  ContentView.swift
//  Teams
//
//  Created by Rawan on 05/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = TeamViewModel()
    
    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.teams) { team in
                    Section(header: Text("\(team.name) (\(team.type.rawValue))")
                        .font(.headline)) {
                            ForEach(team.players) { player in
                                VStack(alignment: .leading) {
                                    Text(player.name)
                                    Text(player.position).foregroundColor(.gray)
                                }
                            }
                        }
                }
            }
        }
            .navigationTitle("Teams & Players")
        }
    }

#Preview {
    ContentView()
}
