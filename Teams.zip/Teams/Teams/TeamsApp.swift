//
//  TeamsApp.swift
//  Teams
//
//  Created by Rawan on 05/09/1446 AH.
//

import SwiftUI

@main
struct TeamsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
