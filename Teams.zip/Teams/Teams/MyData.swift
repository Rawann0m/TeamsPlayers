//
//  MyData.swift
//  Teams
//
//  Created by Rawan on 05/09/1446 AH.
//

import Foundation

// Enum for team types
enum TeamType: String {
    case national = "National"
    case club = "Club"
    case academy = "Academy"
}

// Player struct
struct Player: Identifiable {
    let id = UUID()
    let name: String
    let position: String
}

// Team class 
class Team: Identifiable, ObservableObject {
    let id = UUID()
    let name: String
    let type: TeamType
    @Published var players: [Player]
    
    init(name: String, type: TeamType, players: [Player] = []) {
        self.name = name
        self.type = type
        self.players = players
    }
}
