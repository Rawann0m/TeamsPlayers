//
//  ViewModel.swift
//  Teams
//
//  Created by Rawan on 05/09/1446 AH.
//


import SwiftUI

class TeamViewModel: ObservableObject {
    @Published var teams: [Team] = []
    
    init() {
        loadSampleData()
    }
    
    func loadSampleData() {
        // teams data
        let team1 = Team(name: "Team 1", type: .club, players: [
            Player(name: "Smith", position: "Forward"),
            Player(name: "Mark ", position: "Defender")
        ])
        
        let team2 = Team(name: "Team 2", type: .national, players: [
            Player(name: "Ahmad", position: "Midfielder"),
            Player(name: "Sam", position: "Goalkeeper")
        ])
        let team3 = Team(name: "Team 3", type: .academy, players: [
            Player(name: "John", position: "Midfielder"),
            Player(name: "Ali", position: "Goalkeeper")
        ])
        
        
        teams = [team1, team2,team3]
        //add player
        func addPlayer(to team: Team, player: Player) {
            if let index = teams.firstIndex(where: { $0.id == team.id }) {
                teams[index].players.append(player)
            }
        }
    }
}
